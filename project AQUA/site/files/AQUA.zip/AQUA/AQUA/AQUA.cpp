#include <iostream>
#include "Functions.h"
int main(){
	menu();
}

