#include <iostream>
#include "Functions.h"
int main(){
	int choice;
	int choiceofOcean;
	OCEAN oceans[5];
	int oceansq;
	menu();
}

